const express = require('express');
const cors = require('cors');
const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

// بيانات المنتجات
const products = [
  { id: 1, name: 'Parallettes', price: 2300 },
  { id: 2, name: 'Dip Bars', price: 5600 },
  { id: 3, name: 'Fixed Bar', price: 5400 },
];

// الحصول على المنتجات
app.get('/api/products', (req, res) => {
  res.json(products);
});

// تقديم الطلب
app.post('/api/order', (req, res) => {
  const { name, address, email, phone, cart } = req.body;
  console.log('New Order:', { name, address, email, phone, cart });
  res.json({ message: 'Order submitted successfully!' });
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});